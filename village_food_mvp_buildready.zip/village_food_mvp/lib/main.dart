import 'package:flutter/material.dart';

void main() => runApp(const VillageFoodApp());

class Restaurant { final String name, cuisine, emoji; final double rating; const Restaurant(this.name,this.cuisine,this.emoji,this.rating); }
class Food { final String name, description; final int price; const Food(this.name,this.description,this.price); }

const restaurants = [
  Restaurant('Annavaram Family Restaurant','South Indian • Meals','🍛',4.5),
  Restaurant('Sri Satyanarayana Tiffins','Tiffins • Snacks','🥞',4.4),
  Restaurant('Village Biryani Point','Biryani • Chinese','🍗',4.6),
];
const foods = [
  Food('Chicken Biryani','Aromatic biryani with spicy chicken',180),
  Food('Veg Meals','Traditional Andhra-style meals',120),
  Food('Masala Dosa','Crispy dosa with potato masala',70),
  Food('Chicken Fried Rice','Spicy chicken fried rice',150),
];

class VillageFoodApp extends StatelessWidget {
  const VillageFoodApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner:false, title:'Village Food',
    theme:ThemeData(useMaterial3:true,colorSchemeSeed:Colors.orange,scaffoldBackgroundColor:const Color(0xfffffbf5)),
    home:const HomePage(),
  );
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override Widget build(BuildContext context) => Scaffold(
    appBar:AppBar(title:const Text('Village Food',style:TextStyle(fontWeight:FontWeight.bold)),actions:[IconButton(icon:const Icon(Icons.shopping_cart_outlined),onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const CartPage()))) ]),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(gradient:const LinearGradient(colors:[Color(0xffff9800),Color(0xffff7043)]),borderRadius:BorderRadius.circular(20)),child:const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('మీ ఊరి రుచులు…',style:TextStyle(color:Colors.white,fontSize:25,fontWeight:FontWeight.bold)),Text('మీ ఇంటి గడపకు! 🏠',style:TextStyle(color:Colors.white,fontSize:18)),SizedBox(height:6),Text('Annavaram food delivery',style:TextStyle(color:Colors.white70))])),
      const SizedBox(height:22),const Text('Popular Restaurants',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),const SizedBox(height:10),
      ...restaurants.map((r)=>Card(margin:const EdgeInsets.only(bottom:12),child:ListTile(leading:CircleAvatar(radius:28,child:Text(r.emoji,style:const TextStyle(fontSize:24))),title:Text(r.name,style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text('${r.cuisine}\n⭐ ${r.rating}'),isThreeLine:true,trailing:const Icon(Icons.chevron_right),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>MenuPage(restaurant:r))))),
    ]),
  );
}

class MenuPage extends StatefulWidget { final Restaurant restaurant; const MenuPage({super.key,required this.restaurant}); @override State<MenuPage> createState()=>_MenuPageState(); }
class _MenuPageState extends State<MenuPage> {
  final Map<Food,int> cart={};
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(widget.restaurant.name)),body:ListView.builder(padding:const EdgeInsets.all(12),itemCount:foods.length,itemBuilder:(_,i){final f=foods[i];return Card(child:ListTile(title:Text(f.name,style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text('${f.description}\n₹${f.price}'),isThreeLine:true,trailing:FilledButton(onPressed:()=>setState(()=>cart[f]=(cart[f]??0)+1),child:const Text('ADD'))));}),bottomNavigationBar:cart.isEmpty?null:Padding(padding:const EdgeInsets.all(12),child:FilledButton.icon(icon:const Icon(Icons.shopping_cart),label:Text('View Cart (${cart.values.fold(0,(a,b)=>a+b)})'),onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>CartPage(cart:cart))))));
}

class CartPage extends StatelessWidget { final Map<Food,int> cart; const CartPage({super.key,this.cart=const{}}); @override Widget build(BuildContext context){final total=cart.entries.fold<int>(0,(s,e)=>s+e.key.price*e.value);return Scaffold(appBar:AppBar(title:const Text('Your Cart')),body:cart.isEmpty?const Center(child:Text('Your cart is empty')):ListView(padding:const EdgeInsets.all(16),children:[...cart.entries.map((e)=>ListTile(title:Text(e.key.name),subtitle:Text('₹${e.key.price} × ${e.value}'),trailing:Text('₹${e.key.price*e.value}'))),const Divider(),ListTile(title:const Text('Total',style:TextStyle(fontWeight:FontWeight.bold)),trailing:Text('₹$total',style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold))),FilledButton(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>CheckoutPage(total:total))),child:const Text('Proceed to Checkout'))]));}}

class CheckoutPage extends StatefulWidget { final int total; const CheckoutPage({super.key,required this.total}); @override State<CheckoutPage> createState()=>_CheckoutPageState(); }
class _CheckoutPageState extends State<CheckoutPage>{String payment='UPI';final address=TextEditingController();@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Checkout')),body:ListView(padding:const EdgeInsets.all(16),children:[const Text('Delivery Address',style:TextStyle(fontWeight:FontWeight.bold)),const SizedBox(height:8),TextField(controller:address,maxLines:3,decoration:const InputDecoration(hintText:'House / Street / Area, Annavaram',border:OutlineInputBorder())),const SizedBox(height:20),const Text('Payment Method',style:TextStyle(fontWeight:FontWeight.bold)),RadioListTile(value:'UPI',groupValue:payment,onChanged:(v)=>setState(()=>payment=v!),title:const Text('UPI')),RadioListTile(value:'COD',groupValue:payment,onChanged:(v)=>setState(()=>payment=v!),title:const Text('Cash on Delivery')),ListTile(title:const Text('Order Total'),trailing:Text('₹${widget.total}',style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold))),FilledButton(onPressed:address.text.trim().isEmpty?null:()=>Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>OrderPage(payment:payment,total:widget.total))),child:const Text('Place Order'))]));}
}

class OrderPage extends StatelessWidget { final String payment; final int total; const OrderPage({super.key,required this.payment,required this.total}); @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Order Status')),body:Center(child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[const Icon(Icons.check_circle,size:90,color:Colors.green),const SizedBox(height:16),const Text('Order Placed!',style:TextStyle(fontSize:28,fontWeight:FontWeight.bold)),Text('₹$total • Payment: $payment'),const SizedBox(height:20),const ListTile(leading:Icon(Icons.restaurant),title:Text('Restaurant confirmed'),subtitle:Text('Preparing your order')),const ListTile(leading:Icon(Icons.delivery_dining),title:Text('Delivery partner'),subtitle:Text('Will pick up soon')),const ListTile(leading:Icon(Icons.home),title:Text('Delivery'),subtitle:Text('Coming to your address in Annavaram'))]))));}
